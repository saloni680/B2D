import React from 'react'

const Dashboard = () => {
  return (
    <div>welcome to Dashboard after success login/signup</div>
  )
}

export default Dashboards